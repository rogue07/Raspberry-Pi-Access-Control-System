import mysql.connector

# Connect to MySQL server
password = "!B7!v0??"
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=password
)

# Create database "codedb"
mycursor = mydb.cursor()
mycursor.execute(f"CREATE DATABASE codedb")
print("Database created successfully.")

# Connect to "codedb"
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=password,
  database="codedb"
)
mycursor = mydb.cursor()

# Create table "accessc"
mycursor.execute(f"CREATE TABLE accessc (user_id INT AUTO_INCREMENT PRIMARY KEY, first VARCHAR(20) NOT NULL, last VARCHAR(20) NOT NULL, card VARCHAR(32) NOT NULL, creation VARCHAR(25) NOT NULL, access VARCHAR(25) NOT NULL)")
print("Table created successfully.")

# Display table structure
mycursor.execute(f"DESC accessc")
for x in mycursor:
  print(x)
