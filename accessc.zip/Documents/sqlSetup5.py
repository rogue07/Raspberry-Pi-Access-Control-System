GRANT ALL ON codedb.* To 'root'@'localhost' WITH GRANT OPTION;

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '!Br!v0??';
