import mysql.connector

# establish connection
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="!Br!v0!??"
)

# create database
mycursor = mydb.cursor()
mycursor.execute(f"CREATE DATABASE codedb")

# switch to codedb
mycursor.execute(f"USE codedb")

# create table
mycursor.execute(f"CREATE TABLE accessc(user_id INT AUTO_INCREMENT PRIMARY KEY, first VARCHAR(20) NOT NULL, last VARCHAR(20) NOT NULL, card VARCHAR(32) NOT NULL, creation VARCHAR(25) NOT NULL, access VARCHAR(25) NOT NULL)")

# describe table
mycursor.execute(f"DESC accessc")

# create user with all privileges
#mycursor.execute(f"CREATE USER 'accessc'@'localhost' IDENTIFIED BY 'sqlPASSWORD'")
mycursor.execute(f"GRANT ALL PRIVILEGES ON codedb.* TO 'root'@'localhost'")

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '123abc';

# close cursor and connection
mycursor.close()
mydb.close()
