import mysql.connector

mydb = mysql.connector.connect(      
    host="localhost",      
    user="accessc",
    password="abcd",
    database="codedb"
        )
mycursor = mydb.cursor()
 
