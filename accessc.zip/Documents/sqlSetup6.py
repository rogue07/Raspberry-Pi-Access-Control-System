import mysql.connector

# Get user input for database name, username and password
database_name = input("Enter database name: ")
username = input("Enter username: ")
password = input("Enter password: ")

# Connect to MariaDB
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=""
)

# Create database and user with full access
mycursor = mydb.cursor()
mycursor.execute(f"CREATE DATABASE {database_name}")
mycursor.execute(f"CREATE USER '{username}'@'localhost' IDENTIFIED BY '{password}'")
mycursor.execute(f"GRANT ALL PRIVILEGES ON {database_name}.* TO '{username}'@'localhost'")
