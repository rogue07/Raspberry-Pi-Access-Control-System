import logging
import os 
import time
import subprocess
import keyboard
import mysql.connector
import RPi.GPIO as GPIO
from digitalio import DigitalInOut
from adafruit_pn532.spi import PN532_SPI
from sh import tail
from datetime import datetime
from crontab import CronTab
import os.path
import tkinter as tk

# Log to accessc.log
logging.basicConfig(filename="accessc.log", format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')

def add_user():
    def save():
        fname = fname_entry.get().lower()
        lname = lname_entry.get().lower()

        if not fname:
            error_label.config(text="First name can not be blank")
            return
        if not lname:
            error_label.config(text="Last name can not be blank")
            return

        error_label.config(text="")
        logging.info(f'{fname, lname} was entered.')
        spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
        cs_pin = DigitalInOut(board.D5)
        pn532 = PN532_SPI(spi, cs_pin, debug=False)
        pn532.SAM_configuration()
        print("Waiting for NFC card...")
        time.sleep(1)

        while True:
            time.sleep(1)
            uid = pn532.read_passive_target(timeout=0.5)
            if uid is None:
                continue
            else:
                print("Found card with UID:", [hex(i) for i in uid])
                newCard = [hex(i) for i in uid]
            
            now = datetime.now()
            today = now.strftime("%d/%m/%Y %H:%M")

            mydb = mysql.connector.connect(
            host="localhost",
            user="accessc",
            password="?Ac0ntr0l.",
            database="codedb"
            )

            mycursor = mydb.cursor()

            print("Connected")
            print(newCard)
            print(today)

            mycursor.execute(f'SELECT EXISTS(SELECT * FROM accessc WHERE card = "{newCard}") as OUTPUT')
            myresult = mycursor.fetchone()
            print(myresult)
            print(bool(myresult))
            x = bool(myresult)
            if myresult == True:
                print("Card has already been issues")
                error_label.config(text="Card has already been issued")
                time.sleep(2)
                os.system("clear")
                add_user_window.destroy()
            else:
                time.sleep(1)

            try:
                sql = f'INSERT INTO accessc (first, last, card, creation, access) VALUES ("{fname}", "{lname}", "{newCard}", "{today}", "{today}")'
                mycursor.execute(sql)
            except Exception as e:
                print(e)
                logging.info(f'{e}')
                error_label.config(text="Error saving user")
                time.sleep(3) 
                os.system('clear')
            mydb.commit()
            print(mycursor.rowcount, "record inserted.")
            logging.info(f'{fname, lname} and card have been written to database.')
            os.system('clear')
            time.sleep(2)
            add_user_window.destroy()

    add_user_window = tk.Toplevel()
    add_user_window.title("Add User")
    add_user_window.geometry("250x150")
    add_user_window.resizable(False, False)

    fname_label = tk.Label(add_user_window, text="First name:")
    fname_label.pack()

    fname_entry = tk.Entry(add_user_window)
    fname_entry.pack()

    lname_label = tk.Label(add_user_window, text="Last
