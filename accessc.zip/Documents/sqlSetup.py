# ram
# 16 Jun, 2024


import getpass
import fileinput
import mysql.connector

def update_password_in_file(filename, password):
    for line in fileinput.input(filename, inplace=True):
        print(line.replace("PASSWORD", password), end='')

def setup_database():
    root_password = getpass.getpass("Enter password for 'root' user: ")

    cnx = mysql.connector.connect(user='root', password=root_password, host='localhost')
    cursor = cnx.cursor()

    cursor.execute("CREATE DATABASE IF NOT EXISTS codedb")
    cursor.execute("USE codedb")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accessc (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        first VARCHAR(20) NOT NULL,
        last VARCHAR(20) NOT NULL,
        card VARCHAR(32) NOT NULL,
        creation VARCHAR(25) NOT NULL,
        access VARCHAR(25) NOT NULL
    )
    """)

    accessc_password = getpass.getpass("Enter a password for the database user: ")

    cursor.execute("CREATE USER IF NOT EXISTS 'accessc'@'localhost' IDENTIFIED BY %s", (accessc_password,))
    cursor.execute("GRANT ALL PRIVILEGES ON codedb.* TO 'accessc'@'localhost'")
    cursor.execute("FLUSH PRIVILEGES")

    cursor.execute("SHOW GRANTS FOR 'accessc'@'localhost'")
    print("Privileges granted to database user:")
    for grant in cursor:
        print(grant[0])

    cursor.close()
    cnx.close()

    return accessc_password

def main():
    # Setup the database and get the password for the 'accessc' user
    accessc_password = setup_database()

    # Update the password in the specified files
    update_password_in_file("accessc.py", accessc_password)
    update_password_in_file("scanIn.py", accessc_password)

    print("Scripts updated.")

if __name__ == "__main__":
    main()
