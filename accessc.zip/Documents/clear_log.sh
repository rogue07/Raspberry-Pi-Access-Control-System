#!/bin/bash

# Set the directory path to clean up
directory=/path/to/directory

# Calculate the timestamp for one week ago
timestamp=$(date --date="1 week ago" +%s)

# Find all files in the directory that are older than one week
find $directory -type f -mtime +7 -print0 | while read -d '' file
do
    # Get the file modification timestamp
    filetimestamp=$(date -r $file +%s)
    
    # If the file is older than one week, delete it
    if [ $filetimestamp -lt $timestamp ]; then
        rm $file
        echo "Deleted file: $file"
    fi
done

