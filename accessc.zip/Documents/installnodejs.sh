sudo apt update
sudo apt upgrade

curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -

sudo apt install nodejs

node -v

sudo apt install build-essential
