from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_user', methods=['POST'])
def add_user():
    first_name = request.form['fname']
    last_name = request.form['lname']
    # do something with the form data (e.g. add it to a database)
    return "User {} {} added successfully".format(first_name, last_name)

if __name__ == '__main__':
    app.run()
